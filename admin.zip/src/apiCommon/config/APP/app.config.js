export const STORAGEKEY = {
  token: "user_auth_token",
  authData: "authData",
  userData: "userData",
  layoutData: "layoutData",
};

export const AppSettings = {
  defaultNavigation: "/user",
};
