export const protocol = "http";
export const host = "192.168.0.112";
export const port = "1111";
export const trailUrl = "";
