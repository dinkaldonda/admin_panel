export const protocol = "http";
export const host = "192.168.1.12";
export const port = "6000";
export const trailUrl = "";
